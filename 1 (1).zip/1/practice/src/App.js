import './App.css';
import Card from './components/Card';
import FetchData from './components/FetchData';
import Input from './components/Input';
function App() {



  return (
    <>
      <div className="App" >
        <Card title='Card component' />
        <Input />
        <FetchData />
      </div>
    </>
  );
}

export default App;
