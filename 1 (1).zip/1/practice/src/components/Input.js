import React, { useEffect, useState } from 'react'

export default function Input() {

    const [title, setTitle] = useState('');

    useEffect(() => {

    }, [title]);




    return (
        <div>
            <form>
                <h1>{title}</h1>
                <label>Title</label>
                <input type='text' onChange={(e) => { setTitle(e.target.value) }} />
            </form>
        </div>
    )
}
