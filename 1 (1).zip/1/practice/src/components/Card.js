import { useState } from "react";

export default function Card(props) {

    const [name, setName] = useState('dgddfdf');
    const [first, setfirst] = useState(false);

    function update() {
        setName("kjghkjghjkgkjhgjhugukh");
        setfirst(true);
    }

    let content;

    if (first === true) {
        content = <p>kale raja che</p>
    }
    if (first === false) {
        content = <p>kale college e javanu che</p>
    }

    return (
        <>
            <div>{props.title}</div>
            <div className="display-1">{name}</div>
            <button onClick={update}>Click</button>
            {content}
        </>
    )
}
