import React, { useState } from 'react'

export default function FetchData() {

    const [data, setData] = useState([]);
    const [filter,setFilter] = useState([]);
    
    function FetchDataHandler() {
        fetch('https://swapi.py4e.com/api/films').then((response) => {
            return response.json();
        }).then((data) => {
            setData(data.results);
        })
        filterdata();
    }

    function filterdata(){
        let content = data.filter((item) => {
            return item.episode_id == 5;
        })
        setFilter(content);
    }
    
    return (
        <div>
            {/* {data.map((list) => {
                return <>
                    <p>{list.title}</p>
                    <p>{list.director}</p>
                </>
            })} */}
            {filter.map((list) => {
                return <>
                    <p>{list.title}</p>
                    <p>{list.episode_id}</p>
                </>
            })}
            <button className='btn btn-primary' onClick={FetchDataHandler}>Submit</button>
        </div>
    )
}
