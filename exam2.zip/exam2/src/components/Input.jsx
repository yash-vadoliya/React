import React, { useState } from 'react';

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [inputValues, setInputValues] = useState({ title: '', description: '' });

  const handleInputChange = event => {
    const { name, value } = event.target;
    setInputValues(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleAddTodo = () => {
    if (inputValues.title.trim() !== '' && inputValues.description.trim() !== '') {
      setTodos([...todos, inputValues]);
      setInputValues({ title: '', description: '' });
    }
  };

  const handleDeleteTodo = index => {
    const newTodos = [...todos];
    newTodos.splice(index, 1);
    setTodos(newTodos);
  };

  return (
    <div>
      <h1>Todo List</h1>
      <input
        type="text"
        name="title"
        placeholder="Title"
        value={inputValues.title}
        onChange={handleInputChange}
      />
      <input
        type="text"
        name="description"
        placeholder="Description"
        value={inputValues.description}
        onChange={handleInputChange}
      />
      <button onClick={handleAddTodo}>Add Todo</button>
      <ul>
        {todos.map((todo, index) => (
          <li key={index}>
            <div>
              <strong>{todo.title}</strong>: {todo.description}
            </div>
            <button onClick={() => handleDeleteTodo(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;
